// Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

var aws = require("aws-sdk");
var ses = new aws.SES({ region: "us-west-2" });
exports.handler = async function (event) {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    let body;
      
  let statusCode = '200';
  const headers = {
    'Content-Type': 'application/json',
  };
  
  
  
  var params = {
    Destination: {
      ToAddresses: ["timhoangt@gmail.com",
      "michael.gildein1@marist.edu"],
    },
    Message: {
      Body: {
        Text: { Data: "Timothy Hoang Concordance Lambda Function was executed successfully!" },
      },

      Subject: { Data: "Test Email" },
    },
    Source: "timhoangt@gmail.com",
  };
  
  try {
    switch (event.httpMethod) {
      case 'DELETE':
        //body = await dynamo.delete(JSON.parse(event.body)).promise();
        break;
      case 'GET':
        //body = await dynamo.scan({ TableName: event.queryStringParameters.TableName }).promise();
        break;
      case 'POST':
        var input = event.body.input; 
        console.log(input);
        //Get the item with the matching key (input)
        console.log("computing");
        var output = calculate(input);
        body = output;
        //event.payload.body(output);
        break;
      case 'PUT':
        //body = await dynamo.update(JSON.parse(event.body)).promise();
        break;
      default:
        throw new Error(`Unsupported method "${event.httpMethod}"`);
    }
  } catch (err) {
      statusCode = '400';
      body = err.message;
    } finally {
        body = JSON.stringify(body);
      }
 
    ses.sendEmail(params, function(err, data) {
        if (err) console.log("EMAIL NOT SENT", err, err.stack); // an error occurred
        else     console.log("EMAIL SENT", data);           // successful response
   
    });
    
    return{
    statusCode,
    body,
    headers,
  };

};

/*
* Calculate function
*/
let calculate = function (input) {
  var concordance = getConcordance(input);
  var output = {concordance:concordance, input:input};
  return output;
}

/*
* Save Function
*/
let save = function (data, params) {
  //Add the item to the DB
  docClient.put(params, function (err, data) {
    if (err) {
      console.log("users::save::error - " + JSON.stringify(err, null, 2));                      
    } 
    else {
      console.log("users::save::success" );                      
    }
  });
}

//punctuation I want to remove
var regex = /[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]/g;

//removes punctuation
function removePunctuation(string) {
  return string.replace(regex, "");
}

//Get concordance
function getConcordance(input){
  var low = input.toLowerCase();
  var punc = removePunctuation(low);
  var space = punc.replace(/\s\s+/g, ' ');
  var words = space.split(" ");
  var sorted = words.sort();

  var obj = {};

  for(var i = 0; i < sorted.length; ++i) {
    if(!obj[sorted[i]]) {
      obj[sorted[i]] = 0;
      ++obj[sorted[i]];
    }
  }

  var tokens = Object.keys(obj);
  var counts = Object.values(obj);
  var concordance = [];

  for (var i = 0; i < tokens.length; i++) {
    concordance.push({
      token: tokens[i],
      count: counts[i]
    });
  }

  return concordance;
}